package ���԰�;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import my.lc.library.dataExchange.UserService;
import my.lc.library.interfaces.UserInterface;
import my.lc.library.librarys.User;
import my.lc.library.librarys.book;

public class ���ڵ�¼�����ݽ��� {

	
	
	public static void main(String args[])
	{
		ApplicationContext app= new ClassPathXmlApplicationContext("classpath*:applicationContext.xml");
		UserService userService=app.getBean("userService",UserService.class);
		/*
		�û���¼����
		User r=userService.ImpLogin("092248", "092248");
		
		*/
		//�鼮��ѯ
		book r=userService.ImpLookBook("123");
		System.out.println(r);
		
	}
}
