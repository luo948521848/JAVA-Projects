package DataExchange;

import javax.swing.JOptionPane;

import org.hibernate.Session;

import Interface.Getsession;
import LIbrarys.book;

public class CreateBook {

	private Session session=null;
	private String b_name=null;
	private book b=null;
	
	public CreateBook(book n)
	
	{
		this.b=n;
		try {
			session=new Getsession().getSession();
			//��ʼ�ϴ�����
			session.beginTransaction();
			
			session.save(b);
			//�ύ����
			session.getTransaction().commit();
		} catch (Exception e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			
			session.close();
			
		}
	
	}
}
