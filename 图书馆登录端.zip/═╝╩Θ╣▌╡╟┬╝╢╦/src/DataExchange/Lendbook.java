package DataExchange;

import java.text.Format;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JOptionPane;

import Interface.Getsession;
import LIbrarys.Record;

public class Lendbook {

	private org.hibernate.Session session;
	private Record record;

	//���캯��
	public Lendbook()
	{
		System.out.println("���鹹��ɹ�");
	}
	public void Lend(String name,String bookname)
	{		
		try {
			record=new Record();
			System.out.println(name +bookname);
			Date date=new Date();
			Format format = new SimpleDateFormat("yyyy-MM-dd");
			String Lenddate= format.format(date);
			record.setR_name(name);
			record.setRb_name(bookname);
			record.setLendDate(Lenddate);
			System.out.println(record);
			session=new Getsession().getSession();
			session.beginTransaction();
			session.save(record);
			//�ύ����
			session.getTransaction().commit();
		} catch (Exception e) {
			// TODO �Զ����ɵ� catch ��
		
			JOptionPane.showMessageDialog(null, "���޷�����飬�������ѽ�����", "��ʾ", JOptionPane.ERROR_MESSAGE);
		}
			
	}
}
