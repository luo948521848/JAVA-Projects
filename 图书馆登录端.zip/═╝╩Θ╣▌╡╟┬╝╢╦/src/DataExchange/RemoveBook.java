package DataExchange;

import java.awt.HeadlessException;
import java.io.File;

import javax.swing.JOptionPane;

import org.hibernate.Query;
import org.hibernate.Session;

import Interface.Getsession;
import LIbrarys.book;

public class RemoveBook {
	private Session session=null;
	private String b_name=null;
	private book b=null;
	
	public RemoveBook(String n)
	{
		b_name=n;
		try {
			session=new Getsession().getSession();

			String hql="from book b where b.b_name=:name";
			
			Query query=session.createQuery(hql);

			query.setParameter("name",b_name);
			
			b=(book) query.uniqueResult();
			
			if(b==null)
			{
				JOptionPane.showMessageDialog(null, "���鲻����", "��ʾ", JOptionPane.ERROR_MESSAGE);
   			}
			else
			{
				session.delete(b);
				
				File f=new File("C://Users/Administrator/Desktop/mylibrary/book/"+b.getB_name()+".jpg");
				if(f.isFile() && f.exists())
				{
					f.delete();
					System.out.println("ͼƬ��ɾ��");
				}
				File f1=new File("C://Users/Administrator/Desktop/mylibrary/Code/"+b.getB_name()+".png");
				if(f1.isFile() && f1.exists())
				{
					f1.delete();
					System.out.println("��ά����ɾ��");
				}
				JOptionPane.showMessageDialog(null, "�¼ܳɹ�", "��ʾ", JOptionPane.ERROR_MESSAGE);
			}
		} catch (HeadlessException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			
			session.close();
		}
		
	}
	
	

}
