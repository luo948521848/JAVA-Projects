package Interface;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Getsession {

	private Session session=null;
	private SessionFactory sf=null;
	
	
	
	//�޸ĵĻ�Ҫ�ύ����
	
	public Getsession() {
		super();
		
		 sf =new Configuration().configure().buildSessionFactory();
		 session = sf.openSession();
	    }
	    public Session getSession() {
		return session;
	   }
	public void setSession(Session session) {
		this.session = session;
	}

			
}
