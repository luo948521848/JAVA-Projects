package client;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;

public class Getconnection {
	
	private Socket socket;
	public Getconnection(String ip,String word) throws IOException
	{
		try {
			this.socket=new Socket(ip,9913);
			OutputStream out=socket.getOutputStream();
			PrintWriter wr=new PrintWriter(out);
			wr.write(word);
			wr.flush();
			wr.close();
			out.close();
			socket.close();
			System.out.print("�����ɹ�");
			
		} catch (IOException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}

		
	}

}
