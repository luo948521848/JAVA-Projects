package client;

import java.awt.BorderLayout;

import java.awt.EventQueue;
import java.awt.Image;
import java.awt.TextArea;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;

public class MyFrame extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	private JTextArea textArea;
    private Thread thread;
    private int i=1;
    private boolean iswhile=false;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MyFrame frame = new MyFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MyFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 695, 436);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel ������ = new JLabel("\u804A\u5929\u5BA4");
		������.setForeground(Color.RED);
		������.setFont(new Font("����", Font.BOLD, 15));
		������.setBounds(289, 37, 81, 18);
		contentPane.add(������);
		
		textArea = new JTextArea();
		textArea.setBounds(62, 91, 571, 210);
		contentPane.add(textArea);
		
		JLabel lblNewLabel = new JLabel("\u60A8\u60F3\u8BF4\u7684\u8BDD\uFF1A");
		lblNewLabel.setBounds(39, 337, 126, 18);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(161, 334, 310, 24);
		contentPane.add(textField);
		textField.setColumns(10);
		
		//����
		JButton btnNewButton = new JButton("\u53D1\u9001");
		btnNewButton.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent arg0) {
				String word=textField.getText();
				
				if(i==1)
				{
			    thread.start();
			    i=i-1;
			    System.out.println("start");
				}
				else
				{
					System.out.println("����");
					iswhile=false;
					synchronized (thread){
					thread.notify();
					}
				}
		        try {
					Getconnection g=new Getconnection("127.0.0.1", word);
				} catch (IOException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
		        
		       
		        
		       textField.setText("");
		        iswhile=true;
		       
				
			}
		});
		btnNewButton.setBounds(508, 333, 113, 27);
		contentPane.add(btnNewButton);
		
		//����
		JLabel label= new JLabel("");
		ImageIcon img=new ImageIcon(this.getClass().getResource("/img/timg.jpg"));
		//������Ƭ��С
		img.setImage(img.getImage().getScaledInstance(677,389,Image.SCALE_DEFAULT));
		label.setIcon(img);
		label.setBounds(0, 0, 677, 389);
		contentPane.add(label);
		
		thread=new Thread(new Runnable() {
			
			private ServerSocket server;

			@Override
			public void run() {
				
				try {
					this.server=new ServerSocket(9913);
					 while(true)
					 {
						 
						synchronized (thread) {
							
						while(iswhile)
							{
								thread.wait();
							}
						}
						Socket socket = server.accept();
						//��ȡ������
						InputStream is=socket.getInputStream();
						InputStreamReader isr =new InputStreamReader(is);				
						//ת�����ַ���
						BufferedReader rd=new BufferedReader(isr);
						String str="�ͻ���:"+rd.readLine();
						textArea.append("\r\n"+str);
						System.out.print(str);
					
						
					 }
				
				} catch (IOException | InterruptedException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
				
				finally
				{
					try {
						server.close();
						
					} catch (IOException e) {
						// TODO �Զ����ɵ� catch ��
						e.printStackTrace();
					}
			}
			}
		});
		
	
	
			
		
		

		
	}
}
