package com.lc.shopmarket.JavaBean;

public interface PersonFactory {
	
	

}
