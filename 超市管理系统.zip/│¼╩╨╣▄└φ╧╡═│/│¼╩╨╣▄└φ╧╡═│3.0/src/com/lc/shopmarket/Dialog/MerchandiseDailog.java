package com.lc.shopmarket.Dialog;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.lc.shopmarket.DataExchage.MerchandiseDao;
import com.lc.shopmarket.JavaBean.Merchandise;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.awt.event.ActionEvent;

/*
 *����Ĺ����Լ��ص����������й���ϵͳ��ʾ��Ʒ��Ϣ�ĶԻ���


 *�����Ƿ񱻱�����ԣ���
 *@see(��֮���������)��   ��Դ��
 *                     �м䣺
 *                     ȥ����
 *������˾��λ����007����
 *��Ȩ����007

 *@author(����)����007
 *@since�����ļ�ʹ�õ�jdk����JDK1.8
 *@version���汾����1.0
 *@���ݿ��ѯ��ʽ��mysql+Hibernate
 *@date(��������)��2018/5/29
 *�Ľ���
 *1.
 *2.
 *
 *
 *���������ڣ�
 */
public class MerchandiseDailog extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6758474184641399419L;
	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;

	private Merchandise merchandise;

	public MerchandiseDailog(Merchandise m) {
		;

		merchandise=m;

		setBounds(100, 100, 556, 547);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		setTitle(m.getMerchandiseName()+"�Ļ�����Ϣ");

		JLabel lblNewLabel = new JLabel("\u5546\u54C1\u7F16\u7801\uFF1A");
		lblNewLabel.setBounds(51, 85, 89, 18);
		contentPanel.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("\u7C7B\u578B\u7801\uFF1A");
		lblNewLabel_1.setBounds(51, 149, 72, 18);
		contentPanel.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("\u7C7B\u578B\u7F16\u53F7\uFF1A");
		lblNewLabel_2.setBounds(51, 217, 89, 18);
		contentPanel.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("\u5546\u54C1\u540D\u79F0:");
		lblNewLabel_3.setBounds(51, 288, 105, 18);
		contentPanel.add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("\u96F6\u552E\u4EF7\uFF08\u5143\uFF09\uFF1A");
		lblNewLabel_4.setBounds(51, 363, 105, 18);
		contentPanel.add(lblNewLabel_4);

		JLabel lblNewLabel_5 = new JLabel("\u5546\u54C1\u89C4\u683C\uFF1A");
		lblNewLabel_5.setBounds(291, 85, 100, 18);
		contentPanel.add(lblNewLabel_5);

		JLabel lblNewLabel_6 = new JLabel("\u8BA1\u91CF\u5355\u4F4D\uFF1A");
		lblNewLabel_6.setBounds(291, 149, 100, 18);
		contentPanel.add(lblNewLabel_6);

		JLabel lblNewLabel_7 = new JLabel("\u8FDB\u8D27\u4EF7\uFF1A");
		lblNewLabel_7.setBounds(291, 217, 100, 18);
		contentPanel.add(lblNewLabel_7);

		JLabel lblNewLabel_8 = new JLabel("\u4FDD\u8D28\u671F\uFF1A");
		lblNewLabel_8.setBounds(291, 288, 72, 18);
		contentPanel.add(lblNewLabel_8);

		JLabel lblNewLabel_9 = new JLabel("\u5907\u6CE8\uFF1A");
		lblNewLabel_9.setBounds(291, 363, 72, 18);
		contentPanel.add(lblNewLabel_9);

		//��Ʒ����
		textField = new JTextField();
		textField.setEditable(false);
		textField.setBounds(154, 82, 86, 24);
		textField.setText(m.getMerchandiseNumber());
		contentPanel.add(textField);
		textField.setColumns(10);
		//������
		textField_1 = new JTextField();
		textField_1.setEditable(false);
		textField_1.setBounds(154, 146, 86, 24);
		textField_1.setText(m.getTreatyCode());
		contentPanel.add(textField_1);
		textField_1.setColumns(10);
		//��Ʒ����
		textField_2 = new JTextField();
		textField_2.setEditable(false);
		textField_2.setBounds(154, 214, 86, 24);
		textField_2.setText(m.getSortNumber());
		contentPanel.add(textField_2);
		textField_2.setColumns(10);
		//��Ʒ����
		textField_3 = new JTextField();
		textField_3.setEditable(false);
		textField_3.setBounds(154, 285, 86, 24);
		textField_3.setText(m.getMerchandiseName());
		contentPanel.add(textField_3);
		textField_3.setColumns(10);
		//���ۼ�

		textField_4 = new JTextField();
		textField_4.setBounds(154, 360, 86, 24);
		textField_4.setText(m.getRetailPrice().toString());
		contentPanel.add(textField_4);
		textField_4.setColumns(10);
		//��Ʒ���

		textField_5 = new JTextField();
		textField_5.setEditable(false);
		textField_5.setBounds(405, 82, 86, 24);
		textField_5.setText(m.getMerchandiseSpec());
		contentPanel.add(textField_5);
		textField_5.setColumns(10);
		//������λ

		textField_6 = new JTextField();
		textField_6.setEditable(false);
		textField_6.setBounds(405, 146, 86, 24);
		textField_6.setText(m.getUnits());
		contentPanel.add(textField_6);
		textField_6.setColumns(10);
		//������

		textField_7 = new JTextField();
		textField_7.setBounds(405, 214, 86, 24);
		textField_7.setText(m.getPurchasePrice().toString());
		contentPanel.add(textField_7);
		textField_7.setColumns(10);
		//������
		textField_8 = new JTextField();
		textField_8.setEditable(false);
		textField_8.setBounds(405, 285, 86, 24);
		textField_8.setText(m.getCheckTerm().toString());
		contentPanel.add(textField_8);
		textField_8.setColumns(10);
		//��ע
		textField_9 = new JTextField();
		textField_9.setBounds(405, 360, 86, 24);
		textField_9.setText(m.getRemark());
		contentPanel.add(textField_9);
		textField_9.setColumns(10);

		//����  
		JButton btnNewButton = new JButton("\u8FD4\u56DE");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton.setBounds(51, 438, 113, 27);
		contentPanel.add(btnNewButton);


		//��Ʒ�¼�
		JButton btnNewButton_1 = new JButton("\u4E0B\u67B6");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				//������Ʒ�ı�������¼�


				try {
					MerchandiseDao.getMerchandiseDao().removeMerchandise(merchandise.getMerchandiseNumber());
					
					JOptionPane.showMessageDialog(null, "��Ʒ�¼ܳɹ�", "��ʾ", JOptionPane.ERROR_MESSAGE);
					dispose();
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null, "��Ʒ�¼�ʧ��", "����", JOptionPane.ERROR_MESSAGE);
					dispose();
					new MidMerchandiseDialog("����").setVisible(true);
				}






			}
		});
		btnNewButton_1.setBounds(215, 438, 113, 27);
		contentPanel.add(btnNewButton_1);

		//�޸���Ʒ
		JButton btnNewButton_2 = new JButton("\u4FEE\u6539");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				//������Ʒ�ı�������¼�


				try {

					//�������Ҫ�޸Ŀ��ܸı�Ĳ���
					merchandise.setRetailPrice(new BigDecimal(textField_4.getText().trim()));
					merchandise.setPurchasePrice(new BigDecimal(textField_7.getText().trim()));
					merchandise.setRemark(textField_9.getText().trim());

					MerchandiseDao.getMerchandiseDao().updateMerchandise(merchandise);
				
					JOptionPane.showMessageDialog(null, "��Ʒ�޸ĳɹ�", "��ʾ", JOptionPane.ERROR_MESSAGE);
					dispose();
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null, "��Ʒ�޸�ʧ��", "����", JOptionPane.ERROR_MESSAGE);
					dispose();
					new MidMerchandiseDialog("�޸�").setVisible(true);
				}

			}
		});
		btnNewButton_2.setBounds(378, 438, 113, 27);
		contentPanel.add(btnNewButton_2);
	}
}
