package com.lc.shopmarket.Dialog;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.lc.shopmarket.DataExchage.UserDao;
import com.lc.shopmarket.JavaBean.User;
/*
 *����Ĺ����Լ��ص����������й���ϵͳ�û���Ϣչʾ�Ի���

 *�����Ƿ񱻱�����ԣ���
 *@see(��֮���������)��   ��Դ��
 *                     �м䣺
 *                     ȥ����
 *������˾��λ����007����
 *��Ȩ����007

 *@author(����)����007
 *@since�����ļ�ʹ�õ�jdk����JDK1.8
 *@version���汾����1.0
 *@���ݿ��ѯ��ʽ��mysql+Hibernate
 *@date(��������)��2018/5/23
 *�Ľ���
 *1.��̬��ʾ������Ϣ
 *2.
 *
 *
 *���������ڣ�
 */
public class UserDialog extends JDialog {




	private static final long serialVersionUID = -370034933657178908L;
	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;

	private User user=null;
	private JPasswordField passwordField;


	public UserDialog(User user1) {
		this.user=user1;
		setBounds(100, 100, 520, 465);
		getContentPane().setLayout(new BorderLayout());
		setTitle(user.getUserName()+"�Ļ�����Ϣ");
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel label = new JLabel("\u5361\u53F7");
			label.setBounds(34, 56, 72, 18);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u6301\u5361\u4EBA");
			label.setBounds(34, 103, 72, 18);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u8BC1\u4EF6\u53F7");
			label.setBounds(34, 159, 72, 18);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u5F00\u5361\u65E5\u671F");
			label.setBounds(34, 271, 72, 24);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u7C7B\u578B");
			label.setBounds(260, 56, 72, 18);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u671F\u9650");
			label.setBounds(260, 100, 72, 18);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u79EF\u5206");
			label.setBounds(260, 159, 72, 18);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u6298\u6263\u7387");
			label.setBounds(260, 220, 72, 18);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u5BC6\u7801");
			label.setBounds(34, 220, 72, 18);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u5907\u6CE8");
			label.setBounds(260, 274, 72, 18);
			contentPanel.add(label);
		}

		//���ڱ�ǩ�Լ����ھ���
		//�ô��ھ���
		Dimension dem=Toolkit.getDefaultToolkit().getScreenSize();
		int sHeight=dem.height;
		int sWidth=dem.width;
		int fHeight=this.getHeight();
		int fWidth=this.getWidth();
		this.setLocation((sWidth-fWidth)/2, (sHeight-fHeight)/2);
		//����
		textField = new JTextField();
		textField.setEditable(false);
		textField.setBounds(102, 53, 86, 24);
		contentPanel.add(textField);
		textField.setColumns(10);
		textField.setText(user.getCardId());
		//�ֿ���
		textField_1 = new JTextField();
		textField_1.setBounds(102, 100, 86, 24);
		contentPanel.add(textField_1);
		textField_1.setColumns(10);
		textField_1.setText(user.getUserName());
		//֤����
		//���ʵ�ֲ�����ʾ
		textField_2 = new JTextField();
		textField_2.setBounds(102, 156, 122, 24);
		contentPanel.add(textField_2);
		textField_2.setColumns(10);

		String id=user.getIdcard();
		int size=id.length();
		String id1=id.substring(0,4);
		String id2=id.substring(size-5,size-1);
		String id3=id1+"********"+id2;
		textField_2.setText(id3);



		//����

		passwordField = new JPasswordField();
		passwordField.setBounds(102, 217, 86, 24);
		contentPanel.add(passwordField);
		passwordField.setColumns(10);
		passwordField.setText(user.getPassword());
		//��������
		textField_4 = new JTextField();
		textField_4.setEditable(false);
		textField_4.setBounds(102, 271, 86, 24);
		contentPanel.add(textField_4);
		textField_4.setText(user.getCardDate());
		textField_4.setColumns(10);

		//�û�����

		textField_5 = new JTextField();
		textField_5.setEditable(false);
		textField_5.setText(user.getUserGrade());
		textField_5.setBounds(346, 53, 86, 24);
		textField_5.setColumns(10);
		contentPanel.add(textField_5);

		//����
		textField_6 = new JTextField();
		textField_6.setEditable(false);
		textField_6.setText(user.getTerm());
		textField_6.setBounds(346, 97, 86, 24);
		contentPanel.add(textField_6);
		textField_6.setColumns(10);
		//����
		textField_7 = new JTextField();
		textField_7.setEditable(false);
		textField_7.setText(user.getIntegral());
		textField_7.setBounds(346, 156, 86, 24);
		contentPanel.add(textField_7);
		textField_7.setColumns(10);
		//�ۿ���
		textField_8 = new JTextField();
		textField_8.setEditable(false);
		textField_8.setText(user.getAgio());
		textField_8.setBounds(346, 217, 86, 24);
		contentPanel.add(textField_8);
		textField_8.setColumns(10);
		//��ע
		JTextArea textArea = new JTextArea();
		textArea.setBounds(346, 286, 86, 66);
		contentPanel.add(textArea);


		//�޸İ�ť
		JButton btnNewButton = new JButton("\u4FEE\u6539");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				//ֻ���޸�3������  �ֿ��ˡ�֤��������
				String userName=textField_1.getText().trim();//�û���
				String iDcard=textField_2.getText().trim();//֤����
				//passwordField�Ƕ�������ʽ ����Ҫ����ת��
				char[]m=passwordField.getPassword();
				String password=new String(m);
				user.setUserName(userName);
				user.setIdcard(iDcard);
				user.setPassword(password);


				//��UserDao�����û�����
				try {

					UserDao.getUserDao().update(user);
					//�޸ĳɹ���ʾ
					JOptionPane.showMessageDialog(null, "VIP�޸ĳɹ�", "��ʾ", JOptionPane.ERROR_MESSAGE);
					dispose();
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
					//�޸�ʧ����ʾ
					JOptionPane.showMessageDialog(null, "VIP�޸�ʧ��", "����", JOptionPane.ERROR_MESSAGE);
					textField_1.setText("");
					textField_2.setText("");
					passwordField.setText("");
				}






			}
		});
		btnNewButton.setBounds(195, 365, 113, 27);
		contentPanel.add(btnNewButton);


		//ɾ����ť
		JButton btnNewButton_1 = new JButton("\u5220\u9664");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				//��ȡ���� ͨ���������û�����ע��

				String cardId=user.getIdcard();

				try {

					UserDao.getUserDao().removeUser(cardId);
					JOptionPane.showMessageDialog(null, "VIPע���ɹ�", "��ʾ", JOptionPane.ERROR_MESSAGE);
					dispose();
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null, "VIPע��ʧ��", "����", JOptionPane.ERROR_MESSAGE);
				}





			}









		});
		btnNewButton_1.setBounds(356, 365, 113, 27);
		contentPanel.add(btnNewButton_1);


		//���ذ�ť
		JButton btnNewButton_2 = new JButton("\u8FD4\u56DE");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				dispose();

			}
		});
		btnNewButton_2.setBounds(34, 365, 113, 27);
		contentPanel.add(btnNewButton_2);


	}
}
