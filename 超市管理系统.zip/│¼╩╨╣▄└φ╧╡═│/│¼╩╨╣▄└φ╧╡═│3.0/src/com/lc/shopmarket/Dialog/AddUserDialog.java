package com.lc.shopmarket.Dialog;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;

import com.lc.shopmarket.DataExchage.UserDao;
import com.lc.shopmarket.JavaBean.User;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.awt.event.ActionEvent;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
/*
 *����Ĺ����Լ��ص����������й���ϵͳ�����û��Ի���


 *�����Ƿ񱻱�����ԣ���
 *@see(��֮���������)��   ��Դ��
 *                     �м䣺
 *                     ȥ����
 *������˾��λ����007����
 *��Ȩ����007

 *@author(����)����007
 *@since�����ļ�ʹ�õ�jdk����JDK1.8
 *@version���汾����1.0
 *@���ݿ��ѯ��ʽ��mysql+Hibernate
 *@date(��������)��2018/5/23
 *�Ľ���
 *1.��̬��ʾ������Ϣ
 *2.
 *
 *
 *���������ڣ�
 */
public class AddUserDialog extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1707421076379314803L;
	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	private JTextField textField_4;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;

	private JPasswordField passwordField;
	private JComboBox comboBox ;
	private String DEFAULT_TIME_FORMAT = "yyyy-MM-dd";  
	private String time;  

	public AddUserDialog() {
		setBounds(100, 100, 520, 465);
		getContentPane().setLayout(new BorderLayout());
		setTitle("ע���û�");
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		//���ڱ�ǩ�Լ����ھ���
		//�ô��ھ���
		Dimension dem=Toolkit.getDefaultToolkit().getScreenSize();
		int sHeight=dem.height;
		int sWidth=dem.width;
		int fHeight=this.getHeight();
		int fWidth=this.getWidth();
		this.setLocation((sWidth-fWidth)/2, (sHeight-fHeight)/2);
		{
			JLabel label = new JLabel("\u5361\u53F7");
			label.setBounds(34, 56, 72, 18);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u6301\u5361\u4EBA");
			label.setBounds(34, 103, 72, 18);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u8BC1\u4EF6\u53F7");
			label.setBounds(34, 159, 72, 18);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u5F00\u5361\u65E5\u671F");
			label.setBounds(34, 271, 72, 24);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u7C7B\u578B");
			label.setBounds(260, 56, 72, 18);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u671F\u9650");
			label.setBounds(260, 100, 72, 18);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u79EF\u5206");
			label.setBounds(260, 159, 72, 18);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u6298\u6263\u7387");
			label.setBounds(260, 220, 72, 18);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u5BC6\u7801");
			label.setBounds(34, 220, 72, 18);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u5907\u6CE8");
			label.setBounds(260, 274, 72, 18);
			contentPanel.add(label);
		}


		//����
		textField = new JTextField();
		textField.setBounds(102, 53, 86, 24);
		contentPanel.add(textField);
		textField.setColumns(10);

		//�ֿ���
		textField_1 = new JTextField();
		textField_1.setBounds(102, 100, 86, 24);
		contentPanel.add(textField_1);
		textField_1.setColumns(10);
		//֤����
		textField_2 = new JTextField();
		textField_2.setBounds(102, 156, 86, 24);
		contentPanel.add(textField_2);
		textField_2.setColumns(10);
		//����
		passwordField = new JPasswordField();
		passwordField.setBounds(102, 217, 86, 24);
		contentPanel.add(passwordField);
		passwordField.setColumns(10);
		//��������
		textField_4 = new JTextField();
		textField_4.setEditable(false);
		textField_4.setBounds(102, 271, 86, 24);
		contentPanel.add(textField_4);
		Date date=new Date();
		SimpleDateFormat dateFormatter = new SimpleDateFormat(  
				DEFAULT_TIME_FORMAT); 
		time=dateFormatter.format(date);
		textField_4.setText(time);
		textField_4.setColumns(10);

		//�û����͸�ѡ��
		comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"��ͨ�û�", "����ViP"}));
		comboBox.setBounds(346, 53, 86, 24);
		contentPanel.add(comboBox);
		//����
		textField_6 = new JTextField();
		textField_6.setEditable(false);
		textField_6.setText("1\u5E74");
		textField_6.setBounds(346, 97, 86, 24);
		contentPanel.add(textField_6);
		textField_6.setColumns(10);
		//����
		textField_7 = new JTextField();
		textField_7.setEditable(false);
		textField_7.setText("0");
		textField_7.setBounds(346, 156, 86, 24);
		contentPanel.add(textField_7);
		textField_7.setColumns(10);
		//�ۿ���
		textField_8 = new JTextField();
		textField_8.setEditable(false);
		textField_8.setText("90");
		textField_8.setBounds(346, 217, 86, 24);
		contentPanel.add(textField_8);
		textField_8.setColumns(10);
		//��ע
		JTextArea textArea = new JTextArea();
		textArea.setBounds(346, 286, 86, 66);
		contentPanel.add(textArea);


		//ȡ����ť
		JButton btnNewButton = new JButton("\u53D6\u6D88");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				dispose();
			}
		});
		btnNewButton.setBounds(34, 331, 113, 27);
		contentPanel.add(btnNewButton);


		//ע�ᰴť
		JButton btnNewButton_1 = new JButton("\u6CE8\u518C");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//�����û�ע��
				String cardId=textField.getText().trim();//����
				String userName=textField_1.getText().trim();//�û���
				String iDcard=textField_2.getText().trim();//֤����
				//passwordField�Ƕ�������ʽ ����Ҫ����ת��
				char[]m=passwordField.getPassword();
				String password=new String(m);

				String CardDate=textField_4.getText().trim();//ע������
				String userGrade=comboBox.getSelectedItem().toString();

				String term=textField_6.getText().trim();//����
				String integral=textField_7.getText().trim();//����
				String agio=textField_8.getText().trim();//�ۿ�


				User user=new User(cardId,userName,iDcard,password,CardDate,userGrade,term,integral,agio);

				//ͨ��UserDao�����û�ע��

			
				try {
					UserDao.getUserDao().add(user);
					
					//ע��ɹ�
					JOptionPane.showMessageDialog(null, "VIPע��ɹ�", "��ʾ", JOptionPane.ERROR_MESSAGE);
					dispose();
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
					//ע��ʧ��
					JOptionPane.showMessageDialog(null, "VIPע��ʧ��", "����", JOptionPane.ERROR_MESSAGE);

					//��ǰ�ĸ�ѡ��������
					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
					passwordField.setText("");




				}








			}
		});
		btnNewButton_1.setBounds(204, 331, 113, 27);
		contentPanel.add(btnNewButton_1);



	}

}
