package com.lc.shopmarket.DataExchage;



import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class ClassLog4j {
	
	public ClassLog4j()
	{
		
	}

	//���ü�������ģʽ�����Ż�
	static Logger logger = Logger.getLogger(ClassLog4j.class.getName());


	public static org.apache.log4j.Logger getLogger() {
		PropertyConfigurator.configure("src/log4j.properties");
		return logger;
	}

}
