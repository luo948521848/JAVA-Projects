package �н�ģʽ;

public class Custom {

	private Artisan artisan;

	public Artisan getArtisan() {
		return artisan;
	}

	public void setArtisan(Artisan artisan) {
		this.artisan = artisan;
	}
	
}
