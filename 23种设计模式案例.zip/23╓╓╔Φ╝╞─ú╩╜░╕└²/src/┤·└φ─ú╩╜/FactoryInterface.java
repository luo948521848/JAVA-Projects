package ����ģʽ;

public interface FactoryInterface {

	void Breakmaking();
}
