package ����¼ģʽ;

import org.junit.Test;
public class Manager {

	private Game game;

	public Game getGame() {
		return game;
	}

	public void setGame(Game game) {
		this.game = game;
	}
	
	
	
	@Test
	public void test()
	{
		Manager manager=new Manager();
		Game game=new Game("luo", 99, 3);
		//�����¼
		manager.setGame(game);
		
		//��ȡ��¼
		System.out.println(manager.getGame());
		
	}
	
	
}
