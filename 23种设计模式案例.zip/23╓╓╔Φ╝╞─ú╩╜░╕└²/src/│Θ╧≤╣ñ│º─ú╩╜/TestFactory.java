package ���󹤳�ģʽ;

import org.junit.Test;

public class TestFactory {

	
	@Test
	public void test()
	{
		
		AbstartFactory a=new FactoryA();
		//AbstartFactory b=new FactoryB();
		
		System.out.println("��Ҫ�����");
		a.Breakmaking();
		System.out.println("��Ҫ���ɿ���");
		try {
			Class <?> c=Class.forName("���󹤳�ģʽ.FactoryB");
			a=(AbstartFactory)c.newInstance();
			a.Chocolatmaking();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	

	

	
	
}
