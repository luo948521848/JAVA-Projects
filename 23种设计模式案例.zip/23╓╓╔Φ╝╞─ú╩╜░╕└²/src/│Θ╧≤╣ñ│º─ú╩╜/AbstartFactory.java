package ���󹤳�ģʽ;

public interface AbstartFactory {
	void Breakmaking();
	void Chocolatmaking();
}
