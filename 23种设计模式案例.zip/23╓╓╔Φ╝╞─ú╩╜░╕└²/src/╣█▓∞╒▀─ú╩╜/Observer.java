package �۲���ģʽ;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
public class Observer {

	
	private List <Soldier>list=new ArrayList<>();
	
	private State state;
	
	//����۲�
	public void add(Soldier soldier)
	{
		list.add(soldier);
	}
    //�뿪�۲�
	public void  remove(Soldier soldier)
	{
		list.remove(soldier);
	}
	//�����鱨
	public State getState() {
		return state;
	}
	//��ȡ�鱨
	public void setState(State state) {
		this.state = state;
	}
   
	
	//֪ͨ��ȡ�鱨
	public void inform()
	{
		for(Soldier s :list)
		{
			
			if(this.state!=null)
			{
			this.state.doAction(s);
			}else
			{
				System.out.println("��������״̬");
			}
		}
		
	}
	
	
}
