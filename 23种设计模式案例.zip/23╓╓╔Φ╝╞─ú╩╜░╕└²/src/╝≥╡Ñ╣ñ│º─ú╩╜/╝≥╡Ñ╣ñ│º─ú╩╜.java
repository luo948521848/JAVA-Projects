package �򵥹���ģʽ;

public class �򵥹���ģʽ {

		 public static void main(String[] args) {
			
			 Factory a=new FactoryA();
			 Factory b=new FactoryB();
			 a.runMechine();
			 b.runMechine();
			
			 
		}
	
}
	
	 class Factory
	{
		
		public void runMechine()
		{
			System.out.println("���Ǹ��๤��");
		}
		
	}
	
	 class FactoryA extends Factory
	{
		public void runMechine()
		{
			System.out.println("���ǹ���A");
		}
	}
	 class FactoryB extends Factory
	{
		
		public void runMechine()
		{
			
			System.out.println("���ǹ���B");
		}
	}
	

