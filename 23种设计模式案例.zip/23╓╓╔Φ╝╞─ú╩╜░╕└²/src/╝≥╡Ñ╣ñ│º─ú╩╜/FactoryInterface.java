package �򵥹���ģʽ;

public interface FactoryInterface {

	void runMechine();
}
