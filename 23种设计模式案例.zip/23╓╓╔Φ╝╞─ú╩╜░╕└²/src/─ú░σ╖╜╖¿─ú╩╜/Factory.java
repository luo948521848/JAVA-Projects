package ģ�巽��ģʽ;

public abstract class Factory {
	abstract void runMechine();
	
}
