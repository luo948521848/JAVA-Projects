package ģ�巽��ģʽ;

import org.junit.Test;
public class ʵ�ֽӿ� implements FactoryA{

	@Override
	public void runMechine() {
		// TODO Auto-generated method stub
		System.out.println("��ʼ����");
	}

	
	@Test
	public  void test()
	{
		FactoryA factory=new ʵ�ֽӿ�();
		factory.runMechine();
	}
}

interface FactoryA
{
 void  runMechine();	
}