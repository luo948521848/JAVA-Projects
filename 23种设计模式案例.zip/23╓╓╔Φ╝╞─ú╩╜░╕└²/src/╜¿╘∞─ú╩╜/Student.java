package ����ģʽ;

public interface Student {

	void learnMath();
	void learnEnglish();
}
