package ���ģʽ;


//�ļ����
public class Filer extends Node {

	public Filer(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	

	
	@Override
	void display() {
		// TODO Auto-generated method stub
	System.out.println(name);	
	}

}
