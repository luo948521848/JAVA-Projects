package ����ģʽ;

import org.junit.Test;

public class ����ģʽ {

	@Test
	public void test()
	{
		SingleA.getSingleA();
		SingleB.getSingleB();
		
	}
	
	
	
}

