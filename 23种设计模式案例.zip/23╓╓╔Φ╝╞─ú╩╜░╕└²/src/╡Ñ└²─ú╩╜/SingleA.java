package ����ģʽ;

public class SingleA
{
	
	public static SingleA singleA=null;
	private SingleA()
	{
		System.out.println("������������ģʽ");
	}
	
	
	public static synchronized SingleA getSingleA() {
		
		
		if(singleA==null)
		{
		singleA=new SingleA();
		
		}
		
		return singleA;
	}
	
	
	
}

