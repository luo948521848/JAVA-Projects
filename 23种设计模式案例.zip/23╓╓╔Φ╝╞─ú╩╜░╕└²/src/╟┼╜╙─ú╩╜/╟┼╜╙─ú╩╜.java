package �Ž�ģʽ;

import org.junit.Test;

public class �Ž�ģʽ {

	@Test
	public void test()
	{
		ColocalateFactory a=new BlackFactory();
		a.ColocalateMarking();
		ColocalateFactory b=new WhilteFactory();
		b.ColocalateMarking();
	}
	
	
	
}
interface ColocalateFactory
{
void ColocalateMarking();	
}

class BlackFactory implements ColocalateFactory
{

	@Override
	public void ColocalateMarking() {
		// TODO Auto-generated method stub
		System.out.println("������ɫ�ɿ���");
	}
	
}
class WhilteFactory implements ColocalateFactory
{

	@Override
	public void ColocalateMarking() {
		// TODO Auto-generated method stub
		System.out.println("������ɫ�ɿ���");
	}
	
}