package ״̬ģʽ;

public interface State {
	  void doAction(Soldier soldier);
}
